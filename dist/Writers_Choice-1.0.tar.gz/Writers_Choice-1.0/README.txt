Writer's Choice README
==================

Getting Started
---------------

- cd <directory containing this file>

- $venv/bin/python setup.py develop

- $venv/bin/initialize_Writers_Choice_db development.ini

- $venv/bin/pserve development.ini

